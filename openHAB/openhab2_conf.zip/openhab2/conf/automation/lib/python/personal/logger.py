from core.log import logging, LOG_PREFIX

def logDebug(prefix, text):
	logging.getLogger(LOG_PREFIX+"."+prefix).debug(text)
