"""
A simple wrapper of ``threading.Timer`` to avoid strange behavoir when
promoting a ``threading.Timer`` to global.
"""

import threading

# states for compatibility with ScriptExtension Timer states
NEW = "NEW"
RUNNABLE = "RUNNABLE"
TIMED_WAITING = "TIMED_WAITING"
TERMINATED = "TERMINATED"

__all__ = ["Timer", "NEW", "RUNNABLE", "TIMED_WAITING", "TERMINATED"]


class Timer(object):
    """Creates a timer to call a function after a specified interval.

    Args:
        interval: Seconds to wait before running ``function``, can accept
            a ``float`` for values less than 1 second.
        function: Function to call after interval has passed.
        args: Positional arguments to call ``function`` with.
        kwargs: Keyword arguments to call ``function`` with
    """

    def __init__(self, interval, function, *args, **kwargs):
        self._state = NEW
        self._timer = threading.Timer(interval, function, args, kwargs)
        self._state = RUNNABLE

    def cancel(self):
        """Cancels the timer, regardless of whether it is started or not.
        A timer cannot be started after ``cancel()`` has been called."""
        self._timer.finished.set()

    stop = cancel #: alias of ``cancel()``

    def start(self):
        """Starts the timer thread. Can be cancelled while the timer is still
        wiating, if the function is running it cannot be interrupted."""
        self._timer.start()
        self._state = TIMED_WAITING

    def is_alive(self):
        """Returns ``True`` if the timer has not finished executing, regardless
        of whether it has been started or not."""
        return self._timer.is_alive()

    isAlive = is_alive #: alias of ``is_alive()``

    def get_state(self):
        """Convenience function to mimic ScriptExtension Timer useage.

        Returns:
            | ``timer.NEW`` if instantiated.
            | ``timer.RUNNABLE`` if the timer can be started.
            | ``timer.TIMED_WAITING`` if the timer is started but has not
              finished running yet.
            | ``timer.TERMINATED`` if the timer is finished or was cancelled.
        """
        if self._timer.finished.is_set():
            return TERMINATED
        else:
            return self._state

    getState = get_state #: alias of ``get_state()``