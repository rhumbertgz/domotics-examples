from core.rules import rule
from core.triggers import when
from personal.logger import logDebug
# from org.joda.time import DateTime
from java.time import ZonedDateTime as ZDateTime

lastDoorOpen = ZDateTime.now().minusHours(24)
lastEHallMotion = ZDateTime.now().minusHours(24)
lastFDoorMotion = ZDateTime.now().minusHours(24)

@rule("(Py) Front Door Opened")
@when("Item Front_Door_Contact changed to OPEN")
def front_door_opened(event):
    global lastDoorOpen
    lastDoorOpen = ZDateTime.now()
    logDebug("Demo9", "The Front Door was opened")

@rule("(Py) Motion Detected - Entrance Hall")
@when("Item Entrance_Hall_Motion changed to ON")
def entrance_hall_motion(event):
    global lastEHallMotion, lastFDoorMotion
    lastEHallMotion = ZDateTime.now()
    logDebug("Demo9", "Motion detected in the Entrance Hall")

    if lastFDoorMotion.isBefore(lastEHallMotion.minusSeconds(10)):
        logDebug("Demo9", "Discarding old Motion Detected in the Front Door")
        return
    
    if lastEHallMotion.isAfter(lastDoorOpen) and lastDoorOpen.isAfter(lastFDoorMotion):
        logDebug("Demo9", "Arriving Home!")


@rule("(Py) Motion Detected - Front Door")
@when("Item Front_Door_Motion changed to ON")
def front_door_motion(event):
    global lastEHallMotion, lastFDoorMotion
    lastFDoorMotion = ZDateTime.now()
    logDebug("Demo9", "Motion detected in the Front Door")

    if lastEHallMotion.isBefore(lastFDoorMotion.minusSeconds(10)):
        logDebug("Demo9", "Discarding old Motion Detected in the Entrance Hall")
        return
    
    if lastFDoorMotion.isAfter(lastDoorOpen) and lastDoorOpen.isAfter(lastEHallMotion):
        logDebug("Demo9", "Leaving Home!")    
    