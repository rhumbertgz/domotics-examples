from core.rules import rule
from core.triggers import when
from personal.logger import logDebug
from java.time import ZonedDateTime as ZDateTime
import core

times = []

@rule("(Py) Boiler temperature")
@when("Item Boiler_Temperature changed")
def boiler_temperature(event):
    global times
    logDebug("Demo7","State - {} => {}".format(event.itemName, str(event.itemState)))
    logDebug("Demo7","Times - {}".format(times))
    if event.itemState.intValue() > 60:
        if len(times) == 2:
            if all(map(lambda t: t.isAfter(ZDateTime.now().minusSeconds(5)), times)): 
                logDebug("Demo7","Sending notification ...")
            
            times.insert(0, ZDateTime.now()) 
            times = times[:2]
        else:
            times.insert(0, ZDateTime.now())
            logDebug("Demo7","Temperature > 60 but still not enough values")
    logDebug("Demo7","End Times - {}".format(times))

            
    