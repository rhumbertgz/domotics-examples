from core.rules import rule
from core.triggers import when
from personal.logger import logDebug
from org.joda.time import DateTime
from core.actions import PersistenceExtensions


# @rule("Power: Mains energy monitor monthly")
# @when("Item HEM1_Total_Energy_Cleaned changed")
# def mainsEnergyMonitor(event):
#     lastThreeWeeksUsage = float(str(PersistenceExtensions.sumSince(ir.getItem("HEM1_Total_Energy_Delta"), DateTime.now().minusDays(21))))
#     if lastThreeWeeksUsage > 555:# pick your own value
#        logDebug("Demo8","Send alert - {} => {}".format(event.itemName, str(event.itemState)))
            
    