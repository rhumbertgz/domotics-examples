from core.rules import rule
from core.triggers import when
from personal.logger import logDebug
import core


@rule("(Py) Window open for more than an hour")
@when("Member of gWindows changed")
def window_x_open(event):
    timerX = ir.getItem(event.itemName+"_Timer")
    logDebug("Demo6","State - Window: {} => {}".format(event.itemName, str(event.itemState)))
    if event.itemState == OPEN:
        events.sendCommand(timerX, ON)
        logDebug("Demo6","Set/Reset timer for "+event.itemName)
    else:
        if timerX.state == ON:
            events.postUpdate(timerX, OFF)
            logDebug("Demo6","Timer canceled for " +event.itemName )


@rule("(Py) Timer expired for a Window Contact Sensor")
@when("Member of gWindowTimers received command OFF")
def timer_expired(event):
    logDebug("Demo6","Timer expired for " +event.itemName )
    