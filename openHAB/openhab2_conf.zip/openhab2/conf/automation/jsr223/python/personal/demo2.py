from core.rules import rule
from core.triggers import when
from core.actions import ScriptExecution as SE
from personal.logger import logDebug
from org.joda.time import DateTime
from java.lang.Thread import State
import core

from threading import Timer

timer = None

def start_timer():
    global timer
    timer = Timer(5, lambda: logDebug("Demo2","Timer expired, turning off the light ..."))
    timer.start()

def set_timer():
    global timer
    if timer is None or timer.getState() == State.TERMINATED:
        logDebug("Demo2","Starting new timer")
        start_timer()
    else:
        logDebug("Demo2","Rescheduling timer")
        timer.stop()
        start_timer()

def set_timer2():
    global timer
    if timer is None or timer.hasTerminated():
        logDebug("Demo2","Starting new timer")
        # timer = SE.createTimer(now().plusSeconds(5), lambda: events.sendCommand("Bathroom_Lamp", "OFF"))
        timer = SE.createTimer(DateTime.now().plusSeconds(5), lambda: logDebug("Demo2","Timer expired, turning off the light ..."))
    else:
        logDebug("Demo2","Rescheduling timer")
        timer.reschedule(DateTime.now().plusSeconds(5))

@rule("(Py) Bathroom MotionSensor changed")
@when("Item Bathroom_Motion received update ON")
def bathroom_motion(event):
    logDebug("Demo2","States - Lamp=[{}]   AmbientLight=[{}]".format(items.Bathroom_Lamp, items.Bathroom_AmbientLight))
    if items.Bathroom_AmbientLight.intValue() <= 35 and items.Bathroom_Lamp == OFF:
        logDebug("Demo2","Turning ON Bathroom Lamp")
        events.sendCommand("Bathroom_Lamp", "ON")
        set_timer()
    elif items.Bathroom_Lamp == ON:
        logDebug("Demo2","Light already ON ")
        set_timer()
    # else:
    #     logDebug("Demo2","Motion detected but there is enough ambient light")


    