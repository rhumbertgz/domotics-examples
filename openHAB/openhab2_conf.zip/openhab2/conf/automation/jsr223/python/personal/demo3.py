from core.rules import rule
from core.triggers import when
from personal.logger import logDebug
import core


@rule("(Py) Turn off the radiator of the LIVING_ROOM if one its windows are open")
@when("Member of gLR_Windows changed to OPEN")
def window_open(event):
    logDebug("Demo3","States - Radiator: " + str(items.LivingRoom_Radiator))
    if items.LivingRoom_Radiator == OPEN:
        logDebug("Demo3","Turning off the radiator ...")
    else:
        logDebug("Demo3","The radiator is ClOSED, enjoy the fresh air ...")



    