from core.rules import rule
from core.triggers import when
from personal.logger import logDebug


@rule("(Py) Turn off the radiator of a room if one its windows is open")
@when("Member of gWindows changed to OPEN")
def window_x_open(event):
    roomX = event.itemName.split("_")[0]  # get the name of the room
    radiatorX = roomX+"_Radiator"
    logDebug("Demo5","State - Radiator: {} => {}".format(radiatorX, str(items[radiatorX])))
    if items[radiatorX] == ON:
        logDebug("Demo5","Turning off the radiator: "+radiatorX)
        events.sendCommand(radiatorX, "OFF")
    else:
        logDebug("Demo5","The radiator [{}] is ClOSED, enjoy the fresh air ...".format(radiatorX))



    