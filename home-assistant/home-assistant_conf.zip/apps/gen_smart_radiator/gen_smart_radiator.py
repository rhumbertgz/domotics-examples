import appdaemon.plugins.hass.hassapi as hass

class GenSmartRadiator(hass.Hass):

    def initialize(self):
        self.log('initializing ...')
        group = self.get_state(self.args["group"], attribute = "all")
        sensors = group["attributes"]["entity_id"]

        self.log(self.date())
       
        for sensor in sensors:
            self.log('subscribing to: ' + str(sensor))
            self.listen_state(self.on_windows_open, sensor, new="open")
        
    def on_windows_open(self, entity, attribute, old, new, kwargs):
        radiator = self.__get_radiator(entity)
        if self.get_state(radiator) == "open":
            self.log(f'Turning off {radiator}')
            self.turn_off(radiator)
        else: # only for debugging purposes
            self.log(f'The radiator {radiator} is ClOSED, enjoy the fresh air ...')

    def __get_radiator(self, entity):
        _device, entity_name = self.split_entity(entity)
        room, _window = entity_name.split('_')
        return f'sensor.{room}_radiator'
