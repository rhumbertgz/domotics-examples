import appdaemon.plugins.hass.hassapi as hass
from datetime import datetime, timedelta

class DoorbellNotification(hass.Hass):

    def initialize(self):
        self.log('initializing')
        res = self.get_now_ts()
        self.log(f'state: {res}')
        # initialize last_ring variable to avoid extra `If` condition
        self.last_ring = datetime.now() - timedelta(seconds= 35)
        self.listen_state(self.on_doorbell_press, self.args["sensor"], new="on") 

    def on_doorbell_press(self, entity, attribute, old, new, kwargs):
        if self.last_ring < datetime.now() - timedelta(seconds= 35):
            self.last_ring = datetime.now()
            self.log('sending notification')
        else:
            self.log('Waiting ...')    

