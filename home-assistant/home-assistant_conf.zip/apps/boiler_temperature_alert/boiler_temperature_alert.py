import appdaemon.plugins.hass.hassapi as hass
from datetime import datetime, timedelta

class BoilerTemperatureAlert(hass.Hass):

    def initialize(self):
        self.log('initializing ...')
        self.times = []
        self.listen_state(self.on_temperature_change, self.args["sensor"])

    def on_temperature_change(self, entity, attribute, old, new, kwargs): 
        self.log('on_temperature_change ...') 
        if int(new) > 60:
            if len(self.times) == 2:
                oneHourAgo = datetime.now() - timedelta(seconds= 35)
                if all(map(lambda t: t > oneHourAgo, self.times)): 
                    self.log("Sending notification ...")
                    # your notification

                self.times.insert(0, datetime.now()) 
                # remove the oldest time
                self.times = self.times[:2]
            else:
                self.times.insert(0, datetime.now()) 
                self.log('Temperature > 60 but still not enough values to fire an alert') 
        self.log('End times: ' + str(self.times))          