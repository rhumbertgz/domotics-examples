import appdaemon.plugins.hass.hassapi as hass

class SmartRadiator(hass.Hass):

    def initialize(self):
        self.log('initializing ...')
        group = self.get_state(self.args["windows"], attribute = "all")
        sensors = group["attributes"]["entity_id"]
       
        for sensor in sensors:
            self.log(f'Subscribing to: {self.friendly_name(sensor)}')
            self.listen_state(self.on_windows_open, sensor, new="on")
        
    def on_windows_open(self, entity, attribute, old, new, kwargs):
        radiator = self.args["radiator"]
        if self.get_state(radiator) == "on":
            self.log(f'Turning off the {self.friendly_name(radiator)} ')
            self.turn_off(radiator)
        else: # only for debugging purposes
            self.log(f'The {self.friendly_name(radiator)} is off, enjoy the fresh air ...')
        