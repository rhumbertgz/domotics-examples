import appdaemon.plugins.hass.hassapi as hass

class BathroomSmartLight(hass.Hass):

    def initialize(self):
        self.log('initializing ...')
        self.timer = None
        self.listen_state(self.on_motion_detected, self.args["sensors"]["motion"], new="on") 

    def on_motion_detected(self, entity, attribute, old, new, kwargs):
        light_entity = self.args["lights"]["bathroom"]
        ambient_light = int(self.get_state(self.args["sensors"]["light"]))
        bathroom_light = self.get_state(light_entity)
        if ambient_light <= 35 and bathroom_light == "off":
            self.log('turning on the bathroom light')
            self.turn_on(light_entity)
            self.__set_timer()
        elif bathroom_light == "on":
            self.log('Light already ON ...') 
            self.__set_timer()   


    def __start_timer(self):
        self.timer = self.run_in(self.__turn_off_light, 10)

    def __set_timer(self): 
        if self.timer == None:
            self.log('starting timer ...')   
            self.__start_timer()
        else:
            self.log('rescheduling timer ...')  
            self.cancel_timer(self.timer)  
            self.__start_timer()  

    def __turn_off_light(self, kwargs):
        self.log('Timer expired, turning off the light ...')  
        self.turn_off(self.args["lights"]["bathroom"])         